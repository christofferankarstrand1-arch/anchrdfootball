const Logo = ({ className = "", size = "default" }) => {
  const sizes = {
    small: { width: 32, height: 32, iconScale: 0.8 },
    default: { width: 40, height: 40, iconScale: 1 },
    large: { width: 56, height: 56, iconScale: 1.4 }
  }
  
  const { width, height, iconScale } = sizes[size] || sizes.default
  
  return (
    <svg 
      width={width} 
      height={height} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Football field outline */}
      <rect 
        x="15" 
        y="25" 
        width="70" 
        height="50" 
        rx="4" 
        stroke="currentColor" 
        strokeWidth="3" 
        fill="none"
      />
      
      {/* Center line */}
      <line 
        x1="50" 
        y1="25" 
        x2="50" 
        y2="75" 
        stroke="currentColor" 
        strokeWidth="2"
      />
      
      {/* Center circle */}
      <circle 
        cx="50" 
        cy="50" 
        r="8" 
        stroke="currentColor" 
        strokeWidth="2" 
        fill="none"
      />
      
      {/* Anchor - top circle */}
      <circle 
        cx="50" 
        cy="35" 
        r="4" 
        fill="currentColor"
      />
      
      {/* Anchor - vertical line */}
      <line 
        x1="50" 
        y1="39" 
        x2="50" 
        y2="58" 
        stroke="currentColor" 
        strokeWidth="3" 
        strokeLinecap="round"
      />
      
      {/* Anchor - left arm */}
      <path 
        d="M 50 58 Q 42 58 38 62" 
        stroke="currentColor" 
        strokeWidth="3" 
        strokeLinecap="round" 
        fill="none"
      />
      
      {/* Anchor - right arm */}
      <path 
        d="M 50 58 Q 58 58 62 62" 
        stroke="currentColor" 
        strokeWidth="3" 
        strokeLinecap="round" 
        fill="none"
      />
      
      {/* Anchor - left hook */}
      <circle 
        cx="38" 
        cy="62" 
        r="3" 
        fill="currentColor"
      />
      
      {/* Anchor - right hook */}
      <circle 
        cx="62" 
        cy="62" 
        r="3" 
        fill="currentColor"
      />
    </svg>
  )
}

export default Logo
